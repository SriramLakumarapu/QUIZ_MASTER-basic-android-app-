# Quiz App

<h2>Project Description</h2>
<p>A simple android quiz application programmed in Java. The user can attempt a multiple choice quiz at the end of which an activity displays the number of correct and incorrect answers out of the total questions.<p>
  
<p>The app includes the following activities:</p>
<ol>
  <li>activity_main</li>
  <li>activity_login (No database, credentials provided in the code)</li>
  <li>activity_quiz</li>
  <li>activity_results</li>
  <li>activity_about</li>
</ol>

<p>For any queries contact:</p>
<p>Email: shah.abhay.18bit048@gmail.com</p>
